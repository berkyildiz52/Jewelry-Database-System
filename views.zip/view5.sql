--5.List the customer with highest amount of payment.
Create view [Top Customer] as
Select Top 1  c.fName,c.lName, sum(p.price) totalPayment
From PRODUCT p inner join CART_PRODUCTS cp on p.productId=cp.productId
inner join SHOPPING_CART sc on cp.cartId=sc.cartId
inner join CUSTOMER c on sc.customerId=c.customerId
Group by c.fName,c.lName
Order by totalPayment desc