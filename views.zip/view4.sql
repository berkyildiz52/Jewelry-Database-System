--4.List the products, brand ,category and the gram of the products with their buyers name, surname and address
--which bought by customers who lives in �mraniye.
Create view [Products Sold To Umraniye] as
Select p.productName,p.brandId,p.categoryId,p.gram,c.fName,c.lName,c.address
From PRODUCT p inner join CART_PRODUCTS cp on p.productId=cp.productId
inner join SHOPPING_CART sc on cp.cartId=sc.cartId
inner join CUSTOMER c on sc.customerId=c.customerId
Where c.address like '%Umraniye%'