--7.List the staff with the highest amount of sale and his/her and  his/her total appointment number.
Create view [Top Staff] as
Select Top 1 s.staffName,s.staffSurname, sum(p.price) totalSale, count( distinct a.appointmentId) totalAppointment
From PRODUCT p inner join CART_PRODUCTS cp on p.productId=cp.productId
inner join SHOPPING_CART sc on cp.cartId=sc.cartId
inner join PAYMENT pay on pay.cartId=sc.cartId
inner join STAFF s on s.staffId=pay.StaffId
inner join APPOINTMENT a on a.staffId=s.staffId
Group by s.staffName,s.staffSurname
Order by totalSale desc