--3.List the customers name and surname together with difference between average payment and customers payments who also arranges appointment
Create view [Buyers With Appointment] as
Select c.fName + ' ' + c.lName Customer, sc.totalPrice - (Select avg(sc.totalPrice) From SHOPPING_CART sc) differenceFromAverage, sc.totalPrice
From SHOPPING_CART sc inner join CUSTOMER c on sc.customerId=c.customerId
inner join  APPOINTMENT a on a.customerId=c.customerId
Where a.customerId IS NOT NULL
Group By c.fName, c.lName,sc.totalPrice