--6.List the staffs with their total sale.
Create view [Staff Statistics] as
Select s.staffName,s.staffSurname, sum(p.price) totalSale
From PRODUCT p inner join CART_PRODUCTS cp on p.productId=cp.productId
inner join SHOPPING_CART sc on cp.cartId=sc.cartId
inner join PAYMENT pay on pay.cartId=sc.cartId
inner join STAFF s on s.staffId=pay.StaffId
Group by s.staffName,s.staffSurname
