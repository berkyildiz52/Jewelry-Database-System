--1. List the diamond rings with their  brands and prices in descending order.
Create view [Diamond Rings] as
Select p.productName, b.brandName, p.Price
From PRODUCT p inner join BRAND b on p.brandId=b.brandId inner join CATEGORY c on p.categoryId=c.categoryId 
Where  c.categoryName= 'Yuzuk' and c.madeOf='Pirlanta' 
Order By p.Price desc  OFFSET 0 ROWS