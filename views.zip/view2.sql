--2. For each category list the number of  how many types of product and category name.
Create view [Categories] as
Select c.categoryName, count(*) numberOfProduct
From CATEGORY c
Group By c.categoryName