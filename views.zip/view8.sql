--8.List the appointments in March 2021 with the names of customers and staffs.
Create view [Appointments In March 2021] as
Select a.dateTime, c.fName +' '+ c.lname Customer, s.staffName +' '+s.staffSurname Staff
From APPOINTMENT a inner join CUSTOMER c on a.customerId=c.customerId
inner join  STAFF s on s.staffId=a.staffId
Where DATEPART (year,a.dateTime)=2021 and DATEPART (month,a.dateTime)=03